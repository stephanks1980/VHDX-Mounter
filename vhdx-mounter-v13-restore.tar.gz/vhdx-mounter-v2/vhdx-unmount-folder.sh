#!/usr/bin/env bash
# vhdx-unmount-folder.sh
# Wird von der Nemo-Aktion aufgerufen wenn man auf einen VHDX-Einhängepunkt
# rechtsklickt und "VHDX aushängen" wählt.
#
# Erkennt automatisch ob der Ordner ein VHDX-Einhängepunkt ist und
# hängt das zugehörige NBD-Gerät komplett aus.

if [ -z "$BASH_VERSION" ]; then exec bash "$0" "$@"; fi

FOLDER="$1"
HELPER="/usr/local/lib/vhdx-mounter/vhdx-mount-helper.sh"

# ── Eingabe prüfen ────────────────────────────────────────────────────────────
if [ -z "$FOLDER" ] || [ ! -d "$FOLDER" ]; then
    zenity --error --title="VHDX aushängen" \
        --text="Kein gültiger Ordner angegeben."
    exit 1
fi

if [ ! -x "$HELPER" ]; then
    zenity --error --title="VHDX aushängen" \
        --text="Helfer nicht gefunden:\n$HELPER\n\nBitte erneut installieren:\nsudo bash install.sh"
    exit 1
fi

FOLDER="$(realpath "$FOLDER")"

# ── Prüfen ob Ordner ein Einhängepunkt ist ────────────────────────────────────
if ! mountpoint -q "$FOLDER" 2>/dev/null; then
    zenity --error --title="VHDX aushängen" \
        --text="<tt>$FOLDER</tt>\n\nDieser Ordner ist kein eingehängtes Laufwerk."
    exit 1
fi

# ── Blockgerät hinter diesem Einhängepunkt ermitteln ─────────────────────────
SOURCE_DEV=$(findmnt -rno SOURCE "$FOLDER" 2>/dev/null || true)

if [ -z "$SOURCE_DEV" ]; then
    zenity --error --title="VHDX aushängen" \
        --text="Konnte kein Gerät für\n<tt>$FOLDER</tt>\nermitteln."
    exit 1
fi

# ── Prüfen ob es ein NBD-Gerät ist ───────────────────────────────────────────
if ! echo "$SOURCE_DEV" | grep -q "nbd"; then
    zenity --error --title="VHDX aushängen" \
        --text="<tt>$FOLDER</tt>\n\nDies ist kein VHDX-Laufwerk (Gerät: $SOURCE_DEV).\n\nNur VHDX-Laufwerke können so ausgehängt werden."
    exit 1
fi

# NBD-Basisgerät ermitteln (z.B. /dev/nbd0p1 → /dev/nbd0)
NBD_BASE=$(echo "$SOURCE_DEV" | grep -oP '/dev/nbd\d+')

if [ -z "$NBD_BASE" ]; then
    zenity --error --title="VHDX aushängen" \
        --text="Konnte NBD-Basisgerät nicht ermitteln für:\n$SOURCE_DEV"
    exit 1
fi

# ── Name des Laufwerks für Anzeige ermitteln ──────────────────────────────────
MOUNT_NAME=$(basename "$FOLDER")

# ── Bestätigung ───────────────────────────────────────────────────────────────
zenity --question \
    --title="VHDX aushängen" \
    --text="Laufwerk <b>$MOUNT_NAME</b> ($NBD_BASE) sicher aushängen?\n\nAlle Partitionen dieses Laufwerks werden getrennt." \
    --ok-label="Aushängen" \
    --cancel-label="Abbrechen"

[ $? -ne 0 ] && exit 0

# ── Aushängen via Helfer (einmaliger pkexec) ──────────────────────────────────
OUTPUT=$(pkexec "$HELPER" unmount_all "$NBD_BASE" 2>&1)
RC=$?

if [ $RC -eq 0 ] && echo "$OUTPUT" | grep -q "NBD_DISCONNECTED"; then
    zenity --info --title="VHDX aushängen" \
        --text="Laufwerk <b>$MOUNT_NAME</b> wurde erfolgreich ausgehängt."
else
    ERRORS=$(echo "$OUTPUT" | grep "FAILED:" | sed 's/^FAILED:/  • /' || true)
    zenity --error --title="VHDX aushängen" \
        --text="Fehler beim Aushängen:\n\n${ERRORS:-$OUTPUT}"
fi
