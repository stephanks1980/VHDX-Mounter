#!/usr/bin/env bash
# vhdx-mount-helper.sh – Privilegierter Helfer (einmaliger pkexec-Aufruf)
# Aktionen: mount_all, unmount_all

if [ -z "$BASH_VERSION" ]; then exec bash "$0" "$@"; fi

ACTION="$1"
fail() { echo "ERROR: $*" >&2; exit 1; }

find_free_nbd() {
    for i in $(seq 0 15); do
        SIZE=$(cat /sys/class/block/nbd${i}/size 2>/dev/null || echo "0")
        if [ "$SIZE" = "0" ]; then echo "/dev/nbd$i"; return 0; fi
    done
    return 1
}

# ── Verbinden + Mounten (alles in einem Aufruf) ───────────────────────────────
do_mount_all() {
    local VHDX_FILE="$1"
    local MOUNT_BASE="$2"
    local RUN_UID="$3"
    local RUN_GID="$4"

    [ -f "$VHDX_FILE" ] || fail "Datei nicht gefunden: $VHDX_FILE"

    # NBD-Modul laden
    lsmod | grep -q "^nbd " || modprobe nbd max_part=16

    # Freies NBD-Gerät
    local NBD_DEV
    NBD_DEV=$(find_free_nbd) || fail "Kein freies NBD-Gerät verfügbar."

    # VHDX verbinden
    qemu-nbd --connect="$NBD_DEV" --format=vhdx "$VHDX_FILE" \
        || fail "qemu-nbd konnte VHDX nicht öffnen."
    sleep 1
    partprobe "$NBD_DEV" 2>/dev/null || true
    sleep 1

    echo "NBD:$NBD_DEV"

    local BASE
    BASE=$(basename "$NBD_DEV")
    local VHDX_NAME
    VHDX_NAME=$(basename "$VHDX_FILE")
    VHDX_NAME="${VHDX_NAME%.*}"

    # Partitionen ermitteln
    local PARTS
    PARTS=$(lsblk -rno NAME "$NBD_DEV" 2>/dev/null | grep -v "^${BASE}$" || true)

    if [ -z "$PARTS" ]; then
        PARTS="$BASE"
    fi

    local MOUNTED=0

    for PART in $PARTS; do
        local PART_DEV="/dev/$PART"
        [ -b "$PART_DEV" ] || continue

        # Dateisystem erkennen
        local FSTYPE
        FSTYPE=$(blkid -o value -s TYPE "$PART_DEV" 2>/dev/null || true)
        [ -z "$FSTYPE" ] && continue

        # Einhängepunkt erstellen
        local LABEL
        LABEL=$(blkid -o value -s LABEL "$PART_DEV" 2>/dev/null || true)
        if [ -z "$LABEL" ]; then
            LABEL="${VHDX_NAME}_${PART}"
        fi
        local MPOINT="${MOUNT_BASE}/${LABEL}"

        # Sicherstellen dass Einhängepunkt eindeutig ist
        local IDX=1
        local BASE_MPOINT="$MPOINT"
        while [ -d "$MPOINT" ] && mountpoint -q "$MPOINT" 2>/dev/null; do
            MPOINT="${BASE_MPOINT}_${IDX}"
            IDX=$((IDX + 1))
        done

        mkdir -p "$MPOINT"

        # Mounten mit uid/gid für NTFS/FAT, ohne für ext4 etc.
        local MOUNTED_OK=0
        case "$FSTYPE" in
            ntfs*|vfat|fat*|exfat|msdos)
                if mount -t "$FSTYPE" -o uid="$RUN_UID",gid="$RUN_GID",umask=022 \
                        "$PART_DEV" "$MPOINT" 2>/dev/null; then
                    MOUNTED_OK=1
                fi
                ;;
            *)
                if mount "$PART_DEV" "$MPOINT" 2>/dev/null; then
                    # Verzeichnis für Benutzer zugänglich machen
                    chown "$RUN_UID:$RUN_GID" "$MPOINT" 2>/dev/null || true
                    MOUNTED_OK=1
                fi
                ;;
        esac

        if [ "$MOUNTED_OK" -eq 1 ]; then
            echo "MOUNTED:$MPOINT"
            MOUNTED=$((MOUNTED + 1))
        else
            rmdir "$MPOINT" 2>/dev/null || true
            echo "SKIPPED:$PART_DEV (Dateisystem: $FSTYPE)"
        fi
    done

    if [ "$MOUNTED" -eq 0 ]; then
        qemu-nbd --disconnect "$NBD_DEV" 2>/dev/null || true
        fail "Keine Partition konnte eingehangen werden."
    fi
}

# ── Aushängen + NBD trennen (alles in einem Aufruf) ──────────────────────────
do_unmount_all() {
    local NBD_DEV="$1"
    local BASE
    BASE=$(basename "$NBD_DEV")

    [ -b "$NBD_DEV" ] || fail "Kein gültiges Blockgerät: $NBD_DEV"

    # Alle Partitionen/Geräte ermitteln
    local ALL_DEVS
    ALL_DEVS=$(lsblk -rno NAME "$NBD_DEV" 2>/dev/null || echo "$BASE")

    for DEV_NAME in $ALL_DEVS; do
        local DEV="/dev/$DEV_NAME"
        [ -b "$DEV" ] || continue

        # Nur eingehangene Geräte
        findmnt "$DEV" > /dev/null 2>&1 || continue

        # Einhängepunkt ermitteln
        local MP
        MP=$(findmnt -rno TARGET "$DEV" 2>/dev/null || true)

        # Belegende Prozesse beenden
        if [ -n "$MP" ]; then
            fuser -km "$MP" 2>/dev/null || true
            sleep 1
        fi

        # Aushängen
        if umount "$DEV" 2>/dev/null; then
            echo "UNMOUNTED:$DEV"
            # Leeres Verzeichnis aufräumen
            [ -n "$MP" ] && rmdir "$MP" 2>/dev/null || true
        else
            # Lazy unmount als letzter Ausweg
            umount -l "$DEV" 2>/dev/null && echo "LAZY_UNMOUNTED:$DEV" \
                || echo "FAILED:$DEV"
        fi
    done

    # NBD trennen
    qemu-nbd --disconnect "$NBD_DEV" 2>/dev/null || true
    echo "NBD_DISCONNECTED:$NBD_DEV"
}

case "$ACTION" in
    mount_all)   do_mount_all   "$2" "$3" "$4" "$5" ;;
    unmount_all) do_unmount_all "$2" ;;
    find_nbd)
        # Sucht NBD-Gerät für eine VHDX-Datei – braucht Root für /proc/$PID/fd
        VHDX="$2"
        for i in $(seq 0 15); do
            PID=$(cat /sys/block/nbd${i}/pid 2>/dev/null || true)
            if [ -n "$PID" ] && [ -d "/proc/$PID" ]; then
                if ls -la /proc/${PID}/fd 2>/dev/null | grep -qF "$VHDX"; then
                    echo "/dev/nbd$i"
                    exit 0
                fi
            fi
        done
        exit 1
        ;;
    *) fail "Unbekannte Aktion: $ACTION" ;;
esac
