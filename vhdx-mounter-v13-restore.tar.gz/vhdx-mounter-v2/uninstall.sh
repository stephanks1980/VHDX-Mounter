#!/usr/bin/env bash
# uninstall.sh – Deinstalliert VHDX Mounter

[[ $EUID -ne 0 ]] && echo "Bitte als root ausführen: sudo bash uninstall.sh" && exit 1

REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)

echo "Deinstalliere VHDX Mounter..."

rm -f /usr/local/bin/vhdx-mount.sh
rm -f /usr/local/bin/vhdx-unmount-folder.sh
rm -rf /usr/local/lib/vhdx-mounter/
rm -f /usr/share/applications/vhdx-mounter.desktop
rm -f /etc/polkit-1/rules.d/10-vhdx-mounter.rules
rm -f /usr/share/mime/packages/vhdx.xml
rm -f "$REAL_HOME/.local/share/nautilus/scripts/VHDX einbinden"
rm -f "$REAL_HOME/.local/share/nemo/actions/vhdx-unmount.nemo_action"

update-mime-database /usr/share/mime 2>/dev/null
update-desktop-database /usr/share/applications/ 2>/dev/null

echo "Fertig. VHDX Mounter wurde entfernt."
