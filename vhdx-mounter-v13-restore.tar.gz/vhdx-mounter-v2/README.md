# VHDX Mounter für Debian 13

Bindet `.vhdx`- und `.vhd`-Dateien per Rechtsklick im Dateimanager als Laufwerk ein.

## Enthaltene Dateien

| Datei | Beschreibung |
|-------|-------------|
| `install.sh` | Installationsskript (als root ausführen) |
| `uninstall.sh` | Deinstallationsskript |
| `vhdx-mount.sh` | Hauptskript (Mount/Unmount-Logik) |
| `nautilus-script/VHDX einbinden` | Kontextmenü-Eintrag für Nautilus |
| `thunar-action.xml` | Kontextmenü-Aktion für Thunar |
| `vhdx-mounter.desktop` | „Öffnen mit"-Integration |
| `org.vhdx-mounter.policy` | Polkit-Policy für Passwortabfrage |

## Installation

```bash
cd vhdx-mounter/
sudo bash install.sh
```

Das Skript installiert automatisch:
- **qemu-utils** (stellt `qemu-nbd` bereit)
- **zenity** (grafische Dialoge)
- Kontextmenü-Einträge für **Nautilus** und **Thunar**
- MIME-Typen für `.vhdx` und `.vhd`
- NBD-Kernelmodul (persistiert über Neustarts)

## Verwendung

1. **Rechtsklick** auf eine `.vhdx`- oder `.vhd`-Datei
2. Je nach Dateimanager:
   - **Nautilus**: `Skripte` → `VHDX einbinden`
   - **Thunar**: `Benutzerdefinierte Aktionen` → `VHDX einbinden`
   - Alternativ: `Öffnen mit` → `VHDX Mounter`
3. Passwort-Dialog bestätigen (einmalig per Sitzung)
4. Laufwerk erscheint unter `/media/$USER/vhdx/`

## Wie es funktioniert

```
.vhdx-Datei
    │
    ▼
qemu-nbd (verbindet VHDX mit /dev/nbdX)
    │
    ▼
partprobe (erkennt Partitionen)
    │
    ▼
mount (hängt Dateisystem ein)
    │
    ▼
/media/$USER/vhdx/<name>/ (sichtbar im Dateimanager)
```

## Aushängen

Beim erneuten Rechtsklick auf eine bereits eingebundene VHDX-Datei erscheint ein Dialog mit der Option zum Aushängen. Alternativ über den Dateimanager (Laufwerk auswerfen).

## Unterstützte Dateisysteme

Alle Dateisysteme, die der Linux-Kernel unterstützt: **NTFS**, **FAT32/exFAT**, **ext4**, **ext3**, **Btrfs**, **XFS** und weitere.

Für NTFS wird `ntfs-3g` empfohlen:
```bash
sudo apt install ntfs-3g
```

## Systemvoraussetzungen

- Debian 13 (Trixie) oder neuer
- GNOME (Nautilus) oder Xfce (Thunar)
- Kernel mit NBD-Unterstützung (Standard bei Debian)

## Deinstallation

```bash
sudo bash uninstall.sh
```
