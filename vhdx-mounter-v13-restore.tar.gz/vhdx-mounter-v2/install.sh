#!/usr/bin/env bash
# install.sh – Installiert VHDX Mounter auf Debian 13
# Aufruf: sudo bash install.sh

# Sicherstellen dass wir wirklich bash haben (nicht sh)
if [ -z "$BASH_VERSION" ]; then
    echo "Bitte mit bash ausführen: sudo bash install.sh"
    exit 1
fi

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[FEHLER]${NC} $*"; exit 1; }

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║         VHDX Mounter – Installer         ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Root check
if [ "$EUID" -ne 0 ]; then
    error "Bitte als root ausführen: sudo bash install.sh"
fi

REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Abhängigkeiten
info "Installiere Abhängigkeiten (qemu-utils, zenity, polkitd, pkexec, parted, ntfs-3g)..."
apt-get update -qq
apt-get install -y qemu-utils zenity polkitd pkexec parted ntfs-3g psmisc
success "Abhängigkeiten installiert."

# Hauptskript
info "Installiere Hauptskript nach /usr/local/bin/..."
install -m 755 "$SCRIPT_DIR/vhdx-mount.sh" /usr/local/bin/vhdx-mount.sh
success "vhdx-mount.sh installiert."

# Helfer-Skript (wird via pkexec als root aufgerufen)
info "Installiere privilegierten Helfer..."
mkdir -p /usr/local/lib/vhdx-mounter
install -m 755 "$SCRIPT_DIR/vhdx-mount-helper.sh" /usr/local/lib/vhdx-mounter/vhdx-mount-helper.sh
success "vhdx-mount-helper.sh installiert."

# Unmount-Skript für Nemo-Aktion
info "Installiere Unmount-Skript..."
install -m 755 "$SCRIPT_DIR/vhdx-unmount-folder.sh" /usr/local/bin/vhdx-unmount-folder.sh
success "vhdx-unmount-folder.sh installiert."

# Nemo-Aktion
if command -v nemo > /dev/null 2>&1; then
    info "Installiere Nemo-Aktion..."
    NEMO_ACTIONS="$REAL_HOME/.local/share/nemo/actions"
    mkdir -p "$NEMO_ACTIONS"
    install -m 644 "$SCRIPT_DIR/vhdx-unmount.nemo_action" "$NEMO_ACTIONS/vhdx-unmount.nemo_action"
    chown -R "$REAL_USER:$(id -gn $REAL_USER)" "$NEMO_ACTIONS"
    # Nemo neu starten damit Aktion erscheint
    su -c "nemo -q 2>/dev/null || true" "$REAL_USER" 2>/dev/null || true
    success "Nemo-Aktion installiert."
else
    warn "Nemo nicht gefunden – Nemo-Aktion übersprungen."
fi

# Polkit
info "Installiere Polkit-Berechtigungen..."
# Debian 13 (Trixie): nur noch /etc/polkit-1/rules.d/ (JavaScript-Format)
# .pkla-Dateien werden in Trixie nicht mehr unterstützt
RULES_DIR="/etc/polkit-1/rules.d"
mkdir -p "$RULES_DIR"
install -m 644 "$SCRIPT_DIR/org.vhdx-mounter.rules" "$RULES_DIR/10-vhdx-mounter.rules"
success "Polkit-Regeln installiert ($RULES_DIR)."

# MIME-Typen
info "Registriere MIME-Typen für .vhdx und .vhd..."
cat > /usr/share/mime/packages/vhdx.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-vhdx">
    <comment>Hyper-V Virtual Hard Disk (VHDX)</comment>
    <comment xml:lang="de">Hyper-V Virtuelles Festplattenimage (VHDX)</comment>
    <glob pattern="*.vhdx"/>
    <glob pattern="*.VHDX"/>
  </mime-type>
  <mime-type type="application/x-vhd">
    <comment>Hyper-V Virtual Hard Disk (VHD)</comment>
    <comment xml:lang="de">Hyper-V Virtuelles Festplattenimage (VHD)</comment>
    <glob pattern="*.vhd"/>
    <glob pattern="*.VHD"/>
  </mime-type>
</mime-info>
EOF
update-mime-database /usr/share/mime
success "MIME-Typen registriert."

# Desktop-Eintrag
info "Installiere Desktop-Eintrag..."
install -m 644 "$SCRIPT_DIR/vhdx-mounter.desktop" /usr/share/applications/
update-desktop-database /usr/share/applications/
success "Desktop-Eintrag installiert."

# Nautilus
if command -v nautilus > /dev/null 2>&1; then
    info "Installiere Nautilus-Skript..."
    NAUTILUS_SCRIPTS="$REAL_HOME/.local/share/nautilus/scripts"
    mkdir -p "$NAUTILUS_SCRIPTS"
    install -m 755 "$SCRIPT_DIR/nautilus-script/VHDX einbinden" "$NAUTILUS_SCRIPTS/VHDX einbinden"
    chown "$REAL_USER:$(id -gn $REAL_USER)" "$NAUTILUS_SCRIPTS/VHDX einbinden"
    su -c "nautilus -q 2>/dev/null || true" "$REAL_USER" 2>/dev/null || true
    success "Nautilus-Skript installiert."
else
    warn "Nautilus nicht gefunden – übersprungen."
fi

# Thunar
if command -v thunar > /dev/null 2>&1; then
    info "Konfiguriere Thunar-Aktion..."
    THUNAR_ACTIONS="$REAL_HOME/.config/Thunar/uca.xml"
    mkdir -p "$(dirname "$THUNAR_ACTIONS")"
    if [ -f "$THUNAR_ACTIONS" ]; then
        if ! grep -q "vhdx-mount" "$THUNAR_ACTIONS"; then
            sed -i 's|</actions>||' "$THUNAR_ACTIONS"
            printf '  <action>\n    <icon>drive-harddisk</icon>\n    <n>VHDX einbinden</n>\n    <unique-id>vhdx-mount-001</unique-id>\n    <command>/usr/local/bin/vhdx-mount.sh %%f</command>\n    <description>VHDX-Datei als Laufwerk einbinden</description>\n    <patterns>*.vhdx;*.vhd;*.VHDX;*.VHD</patterns>\n    <startup-notify>false</startup-notify>\n  </action>\n</actions>\n' >> "$THUNAR_ACTIONS"
        fi
    else
        cp "$SCRIPT_DIR/thunar-action.xml" "$THUNAR_ACTIONS"
    fi
    chown -R "$REAL_USER:$(id -gn $REAL_USER)" "$(dirname "$THUNAR_ACTIONS")"
    success "Thunar-Aktion konfiguriert."
else
    warn "Thunar nicht gefunden – übersprungen."
fi

# NBD-Modul
info "Lade NBD-Kernelmodul..."
modprobe nbd max_part=16 2>/dev/null || warn "NBD-Modul nicht geladen (evtl. nach Neustart verfügbar)."
grep -q "^nbd$" /etc/modules 2>/dev/null || echo "nbd" >> /etc/modules
if [ ! -f /etc/modprobe.d/nbd.conf ]; then
    echo "options nbd max_part=16" > /etc/modprobe.d/nbd.conf
fi
success "NBD-Modul konfiguriert."

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║              Installation abgeschlossen!             ║"
echo "╠══════════════════════════════════════════════════════╣"
echo "║  Rechtsklick auf .vhdx/.vhd → »VHDX einbinden«      ║"
echo "║  Laufwerke unter: /media/\$USER/vhdx/               ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
