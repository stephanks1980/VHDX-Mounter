#!/usr/bin/env bash
# vhdx-mount.sh – VHDX Mounter
# Mount/Unmount komplett via pkexec-Helfer – kein udisksctl nötig

if [ -z "$BASH_VERSION" ]; then exec bash "$0" "$@"; fi

VHDX_FILE="$1"
HELPER="/usr/local/lib/vhdx-mounter/vhdx-mount-helper.sh"
MOUNT_BASE="/media/$USER/vhdx"

# ── Eingabe prüfen ────────────────────────────────────────────────────────────
if [ -z "$VHDX_FILE" ]; then
    zenity --error --title="VHDX Mounter" --text="Keine Datei angegeben."
    exit 1
fi
if [ ! -f "$VHDX_FILE" ]; then
    zenity --error --title="VHDX Mounter" --text="Datei nicht gefunden:\n$VHDX_FILE"
    exit 1
fi
if [ ! -x "$HELPER" ]; then
    zenity --error --title="VHDX Mounter" \
        --text="Helfer nicht gefunden:\n$HELPER\n\nBitte erneut installieren:\nsudo bash install.sh"
    exit 1
fi

VHDX_FILE="$(realpath "$VHDX_FILE")"
VHDX_NAME="$(basename "$VHDX_FILE")"
VHDX_NAME="${VHDX_NAME%.*}"

# ── NBD-Gerät zur VHDX-Datei finden ──────────────────────────────────────────
find_nbd_for_vhdx() {
    # Methode 1: direkt ohne Root – über /proc/$PID/fd
    for i in $(seq 0 15); do
        PID=$(cat /sys/block/nbd${i}/pid 2>/dev/null || true)
        if [ -n "$PID" ] && [ -d "/proc/$PID" ]; then
            if ls -la /proc/${PID}/fd 2>/dev/null | grep -qF "$VHDX_FILE"; then
                echo "/dev/nbd$i"
                return 0
            fi
        fi
    done
    # Methode 2: via pkexec-Helfer (kann /proc als Root lesen)
    pkexec "$HELPER" find_nbd "$VHDX_FILE" 2>/dev/null
}

# ── Bereits eingebunden? ──────────────────────────────────────────────────────
EXISTING_NBD=$(find_nbd_for_vhdx 2>/dev/null || true)

if [ -n "$EXISTING_NBD" ]; then
    MOUNTED_POINTS=$(findmnt -rno TARGET,SOURCE \
        | grep "$(basename $EXISTING_NBD)" | awk '{print $1}' || true)

    ACTION=$(zenity --list \
        --title="VHDX Mounter" \
        --text="<b>$VHDX_NAME</b> ist bereits eingebunden.\n\nWas möchtest du tun?" \
        --radiolist --column="" --column="Aktion" \
        TRUE  "Im Dateimanager öffnen" \
        FALSE "Aushängen (unmount)")

    case "$ACTION" in
        "Im Dateimanager öffnen")
            echo "$MOUNTED_POINTS" | while IFS= read -r MP; do
                [ -n "$MP" ] && xdg-open "$MP" &
            done
            ;;
        "Aushängen (unmount)")
            OUTPUT=$(pkexec "$HELPER" unmount_all "$EXISTING_NBD" 2>&1)
            if echo "$OUTPUT" | grep -q "NBD_DISCONNECTED"; then
                zenity --info --title="VHDX Mounter" \
                    --text="<b>$VHDX_NAME</b> wurde erfolgreich ausgehängt."
            else
                zenity --error --title="VHDX Mounter" \
                    --text="Fehler beim Aushängen:\n\n$OUTPUT"
            fi
            ;;
    esac
    exit 0
fi

# ── Mounten ───────────────────────────────────────────────────────────────────
mkdir -p "$MOUNT_BASE"

OUTPUT=$(pkexec "$HELPER" mount_all "$VHDX_FILE" "$MOUNT_BASE" "$UID" "$(id -g)" 2>&1)
RC=$?

if [ $RC -ne 0 ]; then
    ERR=$(echo "$OUTPUT" | grep "^ERROR:" | sed 's/^ERROR: //')
    [ -z "$ERR" ] && ERR="$OUTPUT"
    zenity --error --title="VHDX Mounter – Fehler" \
        --text="Einbinden fehlgeschlagen:\n\n$ERR"
    exit 1
fi

MOUNT_POINTS=$(echo "$OUTPUT" | grep "^MOUNTED:" | sed 's/^MOUNTED://')
COUNT=$(echo "$MOUNT_POINTS" | grep -c "^/" 2>/dev/null || echo 0)

POINTS_DISPLAY=$(echo "$MOUNT_POINTS" | grep "^/" | sed 's/^/  • /')

zenity --question \
    --title="VHDX Mounter – Erfolgreich eingebunden" \
    --text="<b>$VHDX_NAME</b> eingebunden ($COUNT Partition(en)):\n\n<tt>$POINTS_DISPLAY</tt>\n\nIm Dateimanager öffnen?" \
    --ok-label="Öffnen" --cancel-label="Schließen"

if [ $? -eq 0 ]; then
    echo "$MOUNT_POINTS" | grep "^/" | while IFS= read -r MP; do
        [ -d "$MP" ] && xdg-open "$MP" &
    done
fi
